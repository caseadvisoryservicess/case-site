/* CASE OS v4.32.7 - unified CASE Data Grid
   Progressive enhancement for all operational tables. It does not replace business logic;
   it gives every table one visual language, personal layout preferences, visible sort/filter
   affordances, sticky headers, column resizing, density controls and safe Excel-like filters. */
(function(){
  'use strict';
  var GRID_VERSION='4.32.7';
  var OBS=null,TIMER=0,OPEN_MENU=null,OPEN_PANEL=null;

  function e(s){try{return typeof esc==='function'?esc(String(s==null?'':s)):String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}catch(_){return String(s||'');}}
  function userToken(){try{var u=(typeof S!=='undefined'&&S&&S.user)||{};return String(u.id||u.email||u.name||'guest').toLowerCase().replace(/[^a-z0-9_-]+/gi,'_').slice(0,80)||'guest';}catch(_){return 'guest';}}
  function storeKey(){return 'caseos_grid_prefs_v4322::'+userToken();}
  function loadPrefs(){try{var raw=localStorage.getItem(storeKey()),dirty=false;if(!raw){var legacy=localStorage.getItem('caseos_grid_prefs_v4321::'+userToken());if(legacy){raw=legacy;dirty=true;}}var x=JSON.parse(raw||'{}');if(!x||typeof x!=='object')x={};['reg_units','scr_registry'].forEach(function(k){if(x[k]&&x[k]._layoutModel!=='4322'){x[k].pin=0;x[k].widths={};delete x[k].order;x[k]._pinModel='4322';x[k]._layoutModel='4322';dirty=true;}});if(dirty)localStorage.setItem(storeKey(),JSON.stringify(x));return x;}catch(_){return {};}}
  function savePrefs(p){try{localStorage.setItem(storeKey(),JSON.stringify(p||{}));}catch(_){}SRV.dirty=true;pushServerPrefs();}
  /* v4.43: личные настройки таблиц хранятся на сервере (api/user_prefs.php) отдельно для
     каждого пользователя — localStorage лишь кэш этого браузера. Иначе ширины/столбцы
     «сбрасывались» при входе с другого устройства или после чистки браузера. */
  var SRV={pulled:false,dirty:false,t:0,last:''};
  function backendOn(){try{return typeof BACKEND!=='undefined'&&BACKEND&&typeof apiGET==='function'&&typeof apiPOST==='function'&&typeof S!=='undefined'&&S&&S.user;}catch(_){return false;}}
  function pushServerPrefs(){if(!backendOn())return;clearTimeout(SRV.t);SRV.t=setTimeout(function(){try{
    var raw=localStorage.getItem(storeKey())||'{}';
    if(raw===SRV.last)return;SRV.last=raw;
    apiPOST('user_prefs.php',{data:JSON.parse(raw)}).catch(function(){SRV.last='';});
  }catch(_){}},800);}
  function maybePullServerPrefs(){if(SRV.pulled||!backendOn())return;SRV.pulled=true;
    try{apiGET('user_prefs.php').then(function(j){
      var d=j&&j.data;if(!d||typeof d!=='object')return;
      var srvRaw=JSON.stringify(d);if(srvRaw==='{}')return;
      var localRaw=localStorage.getItem(storeKey())||'';
      if(localRaw===srvRaw){SRV.last=srvRaw;return;}
      if(!SRV.dirty){ /* локальных правок в этой сессии нет — серверная копия главнее */
        SRV.last=srvRaw;localStorage.setItem(storeKey(),srvRaw);setTimeout(enhanceAll,0);
      }else{ /* пользователь уже что-то поменял здесь — локальные правки поверх серверных */
        try{var merged=Object.assign({},d,JSON.parse(localRaw||'{}'));localStorage.setItem(storeKey(),JSON.stringify(merged));pushServerPrefs();}catch(_){}
      }
    }).catch(function(){SRV.pulled=false;});}catch(_){SRV.pulled=false;}
  }
  function tablePref(key){var p=loadPrefs();p[key]=p[key]||{};return {all:p,one:p[key]};}
  function mutatePref(key,fn){var p=loadPrefs();p[key]=p[key]||{};if((key==='reg_units'||key==='scr_registry')&&p[key]._layoutModel!=='4322'){p[key]._layoutModel='4322';p[key]._pinModel='4322';}fn(p[key]);savePrefs(p);}
  function currentView(){try{return (typeof S!=='undefined'&&S&&S.view)||'page';}catch(_){return 'page';}}
  function hash(s){var h=2166136261;for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h+=(h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24);}return (h>>>0).toString(36);}
  function cleanId(s,i){s=String(s||'').toLowerCase().replace(/\s+/g,'_').replace(/[^a-zа-яё0-9_]+/gi,'').slice(0,40);return s||('col_'+i);}
  function leafRow(tb){var rs=tb.tHead&&tb.tHead.rows;if(!rs||!rs.length)return null;if(tb.classList&&tb.classList.contains('asaas35-table'))return rs[0];return rs[rs.length-1];}
  function headers(tb){var r=leafRow(tb);return r?Array.prototype.slice.call(r.cells):[];}
  function tableKey(tb,idx){
    if(tb.dataset.caseGridKey)return tb.dataset.caseGridKey;
    var k=tb.getAttribute('data-tblkey');
    if(k)return k;
    if(tb.classList.contains('geo-table')){try{return 'geo_dataset_'+String(typeof GEO_DATASET!=='undefined'?GEO_DATASET:'all');}catch(_){return 'geo_dataset';}}
    if(tb.classList.contains('geo-obj-tbl'))return 'geo_objects';
    var hs=headers(tb).map(function(th){return (th.textContent||'').trim();}).join('|');
    return currentView()+'__'+idx+'__'+hash(hs);
  }
  function isMainGrid(tb){return !!(tb.getAttribute('data-tblkey')||tb.classList.contains('geo-table')||tb.classList.contains('geo-obj-tbl')||tb.classList.contains('reg-grp')||headers(tb).length>=6);}
  function isKnownEngine(tb){return !!(tb.getAttribute('data-grid-engine')||tb.getAttribute('data-tblkey')||tb.classList.contains('geo-table')||tb.classList.contains('geo-obj-tbl')||tb.classList.contains('reg-grp'));}
  function defaultPin(key){return 0;}
  function colIds(tb){return headers(tb).map(function(th,i){var id=th.getAttribute('data-colkey')||th.dataset.caseColId||cleanId((th.querySelector('.th-name,.geo-th-label,.case-grid-label')||th).textContent,i);th.dataset.caseColId=id;return id;});}
  function cellAt(row,i){return row&&row.cells&&row.cells[i]?row.cells[i]:null;}
  function cssEsc(s){try{return window.CSS&&CSS.escape?CSS.escape(String(s)):String(s).replace(/[^a-zA-Z0-9_-]/g,function(c){return '\\'+c;});}catch(_){return String(s).replace(/[^a-zA-Z0-9_-]/g,'_');}}

  function injectCss(){if(document.getElementById('caseGridCss4325'))return;['caseGridCss4321','caseGridCss4322','caseGridCss4324'].forEach(function(id){var old=document.getElementById(id);if(old)old.remove();});var st=document.createElement('style');st.id='caseGridCss4325';st.textContent=`
  :root{--cg-line:color-mix(in srgb,var(--border,#ded8cf) 82%,#9c9389 18%);--cg-head:#faf9f7;--cg-hover:color-mix(in srgb,var(--red-d,#9E0000) 4%,transparent);--cg-sticky:var(--panel,#fff)}
  .case-grid-toolbar{display:flex;align-items:center;gap:6px;min-height:31px;margin:0 0 5px;padding:4px 7px;border:1px solid var(--border);border-radius:9px;background:var(--panel,#fff)}
  .case-grid-toolbar .cg-spacer{flex:1}.case-grid-toolbar .cg-caption{font-size:10.5px;color:var(--muted);font-weight:700;white-space:nowrap}
  .case-grid-toolbar button{font:600 10.5px/1.1 inherit;color:var(--ink);border:1px solid var(--border);background:var(--panel);border-radius:7px;padding:5px 8px;cursor:pointer;white-space:nowrap}.case-grid-toolbar button:hover{border-color:var(--red-d,#9E0000);color:var(--red-d,#9E0000)}
  .case-grid-wrap,.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap{max-width:100%;min-width:0}.tbl-scroll{position:relative}
  table.case-grid th{position:relative}
  table.case-grid{border-collapse:separate!important;border-spacing:0!important;width:auto;min-width:0;background:var(--panel,#fff);font-variant-numeric:tabular-nums;table-layout:fixed!important}
  table.case-grid th,table.case-grid td{border-right:1px solid var(--cg-line)!important;border-bottom:1px solid var(--cg-line)!important;box-sizing:border-box}table.case-grid td{overflow:hidden}table.case-grid thead th{overflow:visible!important}
  table.case-grid th:first-child,table.case-grid td:first-child{border-left:1px solid var(--cg-line)!important}table.case-grid thead tr:first-child th{border-top:1px solid var(--cg-line)!important}
  table.case-grid thead th{position:sticky;top:var(--cg-sticky-top,0px);z-index:8;background:var(--cg-head)!important; /* v4.48.1: липнет КАЖДАЯ ячейка шапки — по горизонтали она привязана к своей колонке и отстать от тела не может (sticky на всём thead отставал по X) */color:#625d56;vertical-align:middle!important;box-shadow:none!important;user-select:none}
  table.case-grid.reg-grp thead tr.grprow th{position:relative!important;top:auto!important;z-index:10;height:24px!important;padding:3px 5px!important;background:var(--cg-head,#faf8f5)!important} /* v4.48.2: беж вместо белого — «белые пятна» над шапкой */ /* v4.48.1: групповой ряд НЕ липнет (Chromium игнорирует разные top у sticky-ячеек многорядного thead — ряды накладывались); липнет ряд колонок */
  table.case-grid.reg-grp thead tr.leafrow th,table.case-grid.reg-grp thead tr:last-child th{top:var(--cg-group-h,24px)!important;z-index:9} /* v4.48.3: ряд колонок липнет ПОД полосой групп; !important — легаси-правило .ux-table-viewport thead th{top:0!important} (v3515-ux) перебивало все смещения шапки */
  table.case-grid tbody tr:hover>td{background:var(--cg-hover)!important}.case-grid-filtered{display:none!important}
  table.case-grid .sortbtn,table.case-grid .case-grid-gsort,table.case-grid .case-grid-sort-idle,table.case-grid .case-grid-sort-on,table.case-grid .geo-th-sort-ic{display:none!important}
  table.case-grid .th1r,table.case-grid .geo-th-label,table.case-grid .case-grid-th{display:grid!important;grid-template-columns:minmax(0,1fr) 18px;align-items:center;gap:3px;min-width:0;width:100%;height:100%;white-space:normal!important}
  table.case-grid .th-name,table.case-grid .case-grid-label{min-width:0;white-space:normal!important;overflow:hidden;text-overflow:ellipsis;overflow-wrap:anywhere;word-break:normal;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;line-clamp:3;text-align:inherit;cursor:default!important}
  table.case-grid .tblfnl,table.case-grid .geo-th-fnl,table.case-grid .case-grid-filter-btn{position:relative;display:inline-flex!important;align-items:center;justify-content:center;width:18px;height:18px;margin:0!important;border:1px solid transparent;border-radius:5px;color:#756e66;background:transparent;cursor:pointer;font-size:12px;line-height:1;flex:none}
  table.case-grid .tblfnl:hover,table.case-grid .geo-th-fnl:hover,table.case-grid .case-grid-filter-btn:hover{color:var(--red-d,#9E0000);border-color:#d9aaa8;background:#fff}
  table.case-grid .tblfnl.on,table.case-grid .geo-th-fnl.on,table.case-grid .case-grid-filter-btn.on{background:var(--red-d,#9E0000)!important;color:#fff!important;border-color:var(--red-d,#9E0000)!important}
  table.case-grid .tblfnl.sort-asc:after,table.case-grid .case-grid-filter-btn.sort-asc:after{content:'↑';position:absolute;right:-4px;top:-6px;font-size:8px;font-weight:900;color:var(--red-d,#9E0000)}table.case-grid .tblfnl.sort-desc:after,table.case-grid .case-grid-filter-btn.sort-desc:after{content:'↓';position:absolute;right:-4px;top:-6px;font-size:8px;font-weight:900;color:var(--red-d,#9E0000)}
  table.case-grid.case-density-comfortable th{padding:9px 10px!important;font-size:10.4px!important;line-height:1.2!important;background:#faf8f5;color:#625d56;font-weight:750}table.case-grid.case-density-comfortable td{padding:9px 10px!important;font-size:11.7px!important;line-height:1.3!important;height:40px;vertical-align:middle}
  table.case-grid tbody tr:hover td{background:rgba(158,0,0,.035)}
  table.case-grid.case-density-compact th{padding:5px 6px!important;font-size:9.4px!important;line-height:1.15!important}table.case-grid.case-density-compact td{padding:5px 6px!important;font-size:11px!important;line-height:1.22!important;height:32px}
  table.case-grid.case-density-ultra th{padding:3px 4px!important;font-size:8.8px!important;line-height:1.1!important}table.case-grid.case-density-ultra td{padding:3px 4px!important;font-size:10.3px!important;line-height:1.15!important;height:27px}
  table.case-grid.reg-grp tbody td{height:32px;vertical-align:middle!important}table.case-grid.reg-grp thead th{font-weight:750!important}
  table.case-grid.reg-grp input,table.case-grid.reg-grp select{font:inherit;border:1px solid var(--border);border-radius:6px;background:var(--panel,#fff);padding:4px 6px;min-height:26px;max-width:100%}
  table.case-grid td select,table.case-grid td input:not([type=checkbox]),table.case-grid td textarea{max-width:100%!important;box-sizing:border-box!important} /* v4.46.2: контролы не выходят за границу столбца при узкой колонке */
  .case-grp-band{position:sticky;top:0;z-index:10;display:flex;align-items:stretch;overflow:hidden;background:var(--cg-head,#faf8f5);border-bottom:1px solid var(--cg-line)}
  .case-grp-band>div{box-sizing:border-box;flex:0 0 auto;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;border-right:1px solid var(--cg-line);background:var(--cg-head,#faf8f5);overflow:hidden;white-space:nowrap;cursor:pointer}
  .case-grp-band>.cgb-pre,.case-grp-band>.cgb-post{cursor:default;border-right:0}
  .case-grp-band>.cgb-post{flex:1 1 auto}
  .case-pin-corner{position:sticky;top:0;left:0;z-index:16;display:block;overflow:hidden;background:var(--cg-head,#faf8f5);border-right:2px solid color-mix(in srgb,var(--red-d,#9E0000) 28%,var(--cg-line));box-shadow:4px 0 10px -6px rgba(35,28,22,.25);pointer-events:auto}
  .case-pin-corner .cpc-grp{background:var(--cg-head,#faf8f5);border-bottom:1px solid var(--cg-line)}
  .case-pin-corner .cpc-row{display:flex;align-items:stretch}
  .case-pin-corner .cpc-cell{position:relative;box-sizing:border-box;flex:0 0 auto;border-right:1px solid var(--cg-line);border-bottom:1px solid var(--cg-line);padding:9px 10px;font-size:10.4px;line-height:1.2;font-weight:750;color:#625d56;background:var(--cg-head,#faf8f5);overflow:hidden;display:flex;align-items:center}
  .case-pin-corner .case-grid-resizer{display:block}
  table.case-grid .case-grid-pin{position:sticky!important;z-index:6;background:var(--cg-sticky)!important}table.case-grid thead .case-grid-pin{z-index:12;background:var(--cg-head)!important;left:auto!important} /* v4.48.2: пины ШАПКИ не липнут сами (Chromium не рисует двухосевой sticky/transform на ячейках) — их показывает угловой блок .case-pin-corner */.case-grid-pin-last{box-shadow:none!important;border-right:2px solid color-mix(in srgb,var(--red-d,#9E0000) 28%,var(--cg-line))!important}
  table.case-grid .case-grid-resizer{position:absolute;right:-4px;top:0;width:9px;height:100%;cursor:col-resize;z-index:60;touch-action:none;background:transparent}table.case-grid .case-grid-resizer:after{content:'';position:absolute;right:0;top:0;bottom:0;width:1px;background:rgba(90,80,70,.28)}table.case-grid th:hover>.case-grid-resizer:after,table.case-grid .case-grid-resizer:hover:after,table.case-grid .case-grid-resizer.drag:after{width:2px;background:var(--red-d,#9E0000)}table.case-grid .case-grid-resizer:hover,table.case-grid .case-grid-resizer.drag{background:linear-gradient(to left,rgba(158,0,0,.10),transparent)}
  table.case-grid tr.filters,table.case-grid tr.fltrow,table.case-grid tr.geo-tfilter-row{display:none!important}
  .case-grid-panel{position:fixed;z-index:10050;width:min(390px,calc(100vw - 20px));max-height:min(650px,calc(100vh - 20px));overflow:auto;background:var(--panel,#fff);border:1px solid var(--border);border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.2);padding:12px;color:var(--ink)}
  .case-grid-panel h3{margin:0;font-size:15px}.case-grid-panel .cg-sub{font-size:10.5px;color:var(--muted);margin:3px 0 10px}.case-grid-panel .cg-row{display:flex;gap:8px;align-items:center;padding:6px 4px;border-bottom:1px solid var(--border);font-size:12px}.case-grid-panel .cg-row span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-grid-panel .cg-actions{display:flex;gap:6px;margin-top:10px;justify-content:flex-end}.case-grid-panel button,.case-grid-panel select,.case-grid-panel input[type=search]{font:600 11px inherit;padding:6px 9px;border:1px solid var(--border);border-radius:7px;background:var(--panel);color:var(--ink)}.case-grid-panel button.primary{background:var(--red-d,#9E0000);color:#fff;border-color:var(--red-d,#9E0000)}
  .case-grid-menu{position:fixed;z-index:10060;width:min(310px,calc(100vw - 16px));max-height:min(540px,calc(100vh - 16px));overflow:auto;background:var(--panel,#fff);border:1px solid var(--border);border-radius:12px;box-shadow:0 14px 40px rgba(0,0,0,.22);padding:9px;color:var(--ink)}.case-grid-menu .cg-sort{display:grid;grid-template-columns:1fr 1fr;gap:5px}.case-grid-menu button{font:600 11px inherit;border:1px solid var(--border);background:var(--panel);color:var(--ink);border-radius:7px;padding:7px;cursor:pointer}.case-grid-menu .cg-title{font-size:10px;font-weight:800;text-transform:uppercase;color:var(--muted);margin:9px 0 5px;padding-top:7px;border-top:1px solid var(--border)}.case-grid-menu input[type=search]{width:100%;box-sizing:border-box;padding:7px 8px;border:1px solid var(--border);border-radius:7px;background:var(--panel);color:var(--ink)}.case-grid-menu .cg-values{max-height:210px;overflow:auto;border:1px solid var(--border);border-radius:7px;padding:4px;margin-top:5px}.case-grid-menu label{display:flex;gap:7px;align-items:center;padding:4px 3px;font-size:12px}.case-grid-menu .cg-footer{display:flex;gap:6px;align-items:center;margin-top:8px}.case-grid-menu .cg-footer .sp{flex:1}.case-grid-menu .primary{background:var(--red-d,#9E0000);color:#fff;border-color:var(--red-d,#9E0000)}
  .geo-table-wrap{width:100%!important}.geo-table.case-grid{min-width:100%!important}
  .case-adaptive-actions{display:flex;gap:7px;align-items:center;flex-wrap:nowrap;min-width:0;margin:0 0 10px}.case-adaptive-actions>.case-action-item{flex:0 0 auto}.case-action-more{margin-left:auto;flex:0 0 auto}.case-action-more:not(.has-items){display:none}.case-action-more .moremenu-pop{max-height:min(70vh,540px);overflow:auto}.case-action-more .moremenu-pop>.case-action-item{display:flex;width:100%;box-sizing:border-box;margin:0 0 5px;justify-content:flex-start}.case-action-more .moremenu-pop>select.case-action-item{display:block}
  @media(max-width:900px){.case-grid-toolbar .cg-caption{max-width:42vw;overflow:hidden;text-overflow:ellipsis}.case-grid-toolbar{overflow:visible}}
  `;document.head.appendChild(st);}
  function applyDensity(tb,key){var p=tablePref(key).one,d=p.density||'comfortable';/* v4.45: эталон — вид гео-таблицы */tb.classList.remove('case-density-comfortable','case-density-compact','case-density-ultra');tb.classList.add('case-density-'+d);}
  function setDensity(key,d){mutatePref(key,function(p){p.density=d;});refresh();}

  function groupState(key){
    try{
      if(key==='reg_units')return {bud:!!(S&&S.regColBud),fac:!!(S&&S.regColFac)};
    }catch(_){}
    return {bud:false,fac:false};
  }
  function effectiveHidden(tb,key){
    var p=tablePref(key).one,h=Object.assign({},p.hidden||{}),ids=colIds(tb),g=groupState(key);
    if(key==='reg_units'){
      if(g.bud)ids.forEach(function(id){if(/^b_/.test(id)&&id!=='b_tots')h[id]=1;});
      if(g.fac)ids.forEach(function(id){if(/^f_/.test(id)&&id!=='f_tots')h[id]=1;});
    }
    return h;
  }
  function scrollWrap(tb){return tb&&tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap');}
  function captureScrollAnchor(key){
    var tb=findTable(key);if(!tb)return null;var wrap=scrollWrap(tb);if(!wrap)return null;
    var sl=wrap.scrollLeft||0;if(sl<=6)return {left:0};
    var ids=colIds(tb),hidden=effectiveHidden(tb,key),cg=tb.querySelector('colgroup'),sum=0,last=null;
    for(var i=0;i<ids.length;i++){
      if(hidden[ids[i]])continue;var w=(cg&&cg.children[i]&&parseFloat(cg.children[i].style.width))||0;
      if(sum+w>sl)return {id:ids[i],offset:Math.max(0,sl-sum),index:i};
      sum+=w;last={id:ids[i],offset:0,index:i};
    }
    return last||{left:0};
  }
  function restoreScrollAnchor(tb,key,a){
    if(!a)return;var wrap=scrollWrap(tb);if(!wrap)return;if(a.left===0){wrap.scrollLeft=0;return;}
    var ids=colIds(tb),hidden=effectiveHidden(tb,key),cg=tb.querySelector('colgroup'),target=a.id;
    if(!target||hidden[target]){
      for(var j=Math.min(ids.length-1,a.index||0);j>=0;j--){if(!hidden[ids[j]]){target=ids[j];break;}}
    }
    var sum=0;for(var i=0;i<ids.length;i++){if(hidden[ids[i]])continue;if(ids[i]===target)break;sum+=(cg&&cg.children[i]&&parseFloat(cg.children[i].style.width))||0;}
    wrap.scrollLeft=Math.max(0,sum+(a.offset||0));
  }

  function adjustGroupedHeader(tb,key,hidden){if(!tb.classList.contains('reg-grp')||!tb.tHead||tb.tHead.rows.length<2)return;var ids=colIds(tb),gr=tb.tHead.rows[0],cells=Array.prototype.slice.call(gr.cells),bud=cells.find(function(c){return c.classList.contains('grp-bud');}),fac=cells.find(function(c){return c.classList.contains('grp-fac');});if(!bud||!fac)return;var bi=ids.findIndex(function(id){return id.indexOf('b_')===0;}),fi=ids.findIndex(function(id){return id.indexOf('f_')===0;}),post=ids.findIndex(function(id){return id==='vars';});if(bi<0||fi<0||post<0)return;
   /* v4.48.1: скрытые столбцы схлопываются на уровне col — ячейкам группового ряда display НЕ трогаем
      (индексные сдвиги невозможны), colspan групп остаётся ПОЛНЫМ (collapse-колонки считаются в colspan),
      подпись группы прячется только когда вся группа скрыта */
   cells.forEach(function(c){if(c.style.display==='none')c.style.display='';});
   /* v4.49.1: colspan группы = число ячеек, реально занимающих колонку.
      display:none (так сворачиваются группы «Бюджет»/«Факт») ячейку из ряда УБИРАЕТ — считать нельзя,
      иначе групповой ряд шире тела и хвостовые столбцы выдавливаются за край.
      visibility:collapse (так прячутся столбцы через «Столбцы») слот оставляет — считать нужно. */
   var hs2=headers(tb);
   var shown=function(from,to){var n=0;for(var i=from;i<to;i++){var th=hs2[i];if(th&&getComputedStyle(th).display!=='none')n++;}return n;};
   var bv=shown(bi,fi),fv=shown(fi,post);
   bud.colSpan=Math.max(1,bv);fac.colSpan=Math.max(1,fv);
   bud.style.visibility=bv?'':'hidden';fac.style.visibility=fv?'':'hidden';} 
  function applyVisibility(tb,key){var hidden=effectiveHidden(tb,key),ids=colIds(tb),hs=headers(tb),body=tb.tBodies&&tb.tBodies[0],cg=tb.querySelector('colgroup');
   /* v4.48.1: скрытие ТОЛЬКО через col{visibility:collapse} — браузер прячет th и td одной операцией,
      рассинхрон «шапка без столбца, тело со столбцом» невозможен по построению. Старые display:none
      на ячейках вычищаются (могли остаться от прежних версий и сдвигать раскладку). */
   ids.forEach(function(id,i){var off=!!hidden[id],th=hs[i],co=cg&&cg.children[i];
    if(th&&th.style.display==='none')th.style.display='';
    if(co){if(co.style.display==='none')co.style.display='';co.style.visibility=off?'collapse':'';}
    if(body)Array.prototype.forEach.call(body.rows,function(r){var c=cellAt(r,i);if(c&&c.style.display==='none')c.style.display='';});
   });adjustGroupedHeader(tb,key,hidden);syncTableWidth(tb,key);}
  function visibleIndices(tb,key){var hidden=effectiveHidden(tb,key),ids=colIds(tb),a=[];ids.forEach(function(id,i){if(!hidden[id])a.push(i);});return a;}
  function applyOrder(tb,key){if(!tb.tHead)return;var aligned=tb.tHead.rows.length===1||tb.classList.contains('asaas35-table');if(!aligned)return;var p=tablePref(key).one,order=Array.isArray(p.order)?p.order:[];if(!order.length)return;var row=leafRow(tb),hs=Array.prototype.slice.call(row.cells),ids=hs.map(function(th,i){return th.getAttribute('data-colkey')||th.dataset.caseColId||cleanId(th.textContent,i);}),map={};ids.forEach(function(id,i){map[id]=i;});var seq=[];order.forEach(function(id){if(Object.prototype.hasOwnProperty.call(map,id)&&seq.indexOf(map[id])<0)seq.push(map[id]);});ids.forEach(function(_,i){if(seq.indexOf(i)<0)seq.push(i);});if(seq.every(function(v,i){return v===i;}))return;Array.prototype.forEach.call(tb.tHead.rows,function(hr){var cells=Array.prototype.slice.call(hr.cells);if(cells.length===ids.length&&cells.every(function(c){return (c.colSpan||1)===1;}))seq.forEach(function(old){hr.appendChild(cells[old]);});});var cg=tb.querySelector('colgroup'),cols=cg?Array.prototype.slice.call(cg.children):[];if(cg&&cols.length===ids.length)seq.forEach(function(old){cg.appendChild(cols[old]);});Array.prototype.forEach.call(tb.tBodies||[],function(body){Array.prototype.forEach.call(body.rows,function(r){var cs=Array.prototype.slice.call(r.cells);if(cs.length!==ids.length||cs.some(function(c){return (c.colSpan||1)!==1;}))return;seq.forEach(function(old){r.appendChild(cs[old]);});});});}
  function clearPins(tb){tb.querySelectorAll('.case-grid-pin,.case-grid-pin-last').forEach(function(x){x.classList.remove('case-grid-pin','case-grid-pin-last');x.style.left='';x.style.transform='';});var w=tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap');var c=w&&w.querySelector(':scope > .case-pin-corner');if(c)c.remove();}
  function maxPinCount(tb,key){var ids=colIds(tb);if(tb.classList.contains('reg-grp')){var b=ids.findIndex(function(id){return id.indexOf('b_')===0;});return b<0?0:b;}return Math.min(6,ids.length);}
  function groupPrefixCells(tb,count){if(!tb.classList.contains('reg-grp')||!tb.tHead||tb.tHead.rows.length<2)return[];var gr=tb.tHead.rows[0],cells=Array.prototype.slice.call(gr.cells),bud=cells.findIndex(function(c){return c.classList.contains('grp-bud');});return bud<0?[]:cells.slice(0,Math.min(count,bud));}
  function applyPins(tb,key){clearPins(tb);var p=tablePref(key).one,pin=('pin' in p)?Math.max(0,+p.pin||0):defaultPin(key),cap=maxPinCount(tb,key);pin=Math.min(pin,cap);if(!pin)return;var vis=visibleIndices(tb,key).filter(function(i){return i<cap;}).slice(0,pin),hs=headers(tb),body=tb.tBodies&&tb.tBodies[0],cg=tb.querySelector('colgroup'),left=0,gpcs=groupPrefixCells(tb,cap);vis.forEach(function(i,n){var th=hs[i],w=(cg&&cg.children[i]&&parseFloat(cg.children[i].style.width))||Math.round(th.getBoundingClientRect().width)||80;if(!th)return;th.classList.add('case-grid-pin');th.style.left=left+'px';var g=gpcs[i];if(g&&g.style.display!=='none'){g.classList.add('case-grid-pin');g.style.left=left+'px';}if(body)Array.prototype.forEach.call(body.rows,function(r){var c=cellAt(r,i);if(c&&c.style.display!=='none'){c.classList.add('case-grid-pin');c.style.left=left+'px';}});if(n===vis.length-1){th.classList.add('case-grid-pin-last');if(g)g.classList.add('case-grid-pin-last');if(body)Array.prototype.forEach.call(body.rows,function(r){var c=cellAt(r,i);if(c)c.classList.add('case-grid-pin-last');});}left+=w;});try{buildPinCorner(tb,key);}catch(_){}try{buildGrpBand(tb);}catch(_){}}
  function gridWidthPrefs(key){var p=tablePref(key).one;return p.widths||{};}
  function syncTableWidth(tb,key){try{var cg=tb.querySelector('colgroup'),ids=colIds(tb),hidden=effectiveHidden(tb,key),total=0;if(!cg)return 0;ids.forEach(function(id,i){if(hidden[id])return;var c=cg.children[i];if(!c)return;var w=parseFloat(c.style.width)||0;if(w>0)total+=w;});total=Math.max(1,Math.round(total));tb.style.width=total+'px';tb.style.minWidth='100%';tb.style.maxWidth='none';return total;/* v4.42: min-width 100% — узкая таблица растягивается на всю карточку (свободное место при table-layout:fixed браузер делит между столбцами), вместо «сжатых» столбцов с переносами */}catch(_){return 0;}}
  function setGridWidth(key,id,w){mutatePref(key,function(p){p.widths=p.widths||{};p.widths[id]=Math.round(w);});}
  function captureWidths(tb,key){try{var ids=colIds(tb),cg=tb.querySelector('colgroup'),hs=headers(tb),ws={};ids.forEach(function(id,i){var w=(cg&&cg.children[i]&&parseFloat(cg.children[i].style.width))||(hs[i]&&hs[i].getBoundingClientRect().width)||0;if(w>=40)ws[id]=Math.round(w);});if(Object.keys(ws).length)mutatePref(key,function(p){p.widths=Object.assign(p.widths||{},ws);});tb.removeAttribute('data-cg-capture');}catch(_){}}
  function defaultWidth(key,id,i,label){label=String(label||'').toLowerCase();if(id==='_select'||label==='')return 32;if(id==='code'||label.indexOf('помещение')>=0)return 112;if(id==='block')return 76;if(id==='floor')return 88;if(id==='cat')return 165;if(id==='area'||label==='м²')return 72;if(/^b_|^f_/.test(id))return label.indexOf('итого')>=0?132:label.indexOf('capex')>=0?105:122;if(id==='vars')return 160;if(id==='broker')return 130;if(id==='comment')return 180;if(id==='status')return 120;return Math.max(78,Math.min(190,Math.round(label.length*6.1+42)));}
  function ensureColgroup(tb,key){var ids=colIds(tb),hs=headers(tb),cg=tb.querySelector('colgroup');if(!cg||cg.children.length!==ids.length){if(cg)cg.remove();cg=document.createElement('colgroup');ids.forEach(function(id){var c=document.createElement('col');c.dataset.caseColId=id;cg.appendChild(c);});tb.insertBefore(cg,tb.firstChild);}var ws=gridWidthPrefs(key);ids.forEach(function(id,i){var c=cg.children[i],label=(hs[i]&&hs[i].textContent)||'';c.dataset.caseColId=id;var w=ws[id]||parseFloat(c.style.width)||defaultWidth(key,id,i,label);w=Math.max(32,Math.min(600,w));c.style.width=Math.round(w)+'px';if(hs[i]){hs[i].style.width='';hs[i].style.minWidth='';hs[i].style.maxWidth='';}});tb.style.tableLayout='fixed';syncTableWidth(tb,key);return cg;}
  function applyStoredWidths(tb,key){ensureColgroup(tb,key);var gr=tb.tHead&&tb.tHead.rows[0];if(tb.classList.contains('reg-grp')&&gr){requestAnimationFrame(function(){tb.style.setProperty('--cg-group-h',Math.max(22,Math.ceil(gr.getBoundingClientRect().height))+'px');});}}
  function autoFitColumn(tb,key,i){var hs=headers(tb),th=hs[i];if(!th)return;var label=(th.querySelector('.th-name,.case-grid-label')||th).textContent||'',max=Math.max(54,Math.min(260,Math.round(Math.min(label.length,32)*5.8+38))),body=tb.tBodies&&tb.tBodies[0];if(body){for(var r=0;r<Math.min(body.rows.length,100);r++){var c=cellAt(body.rows[r],i);if(!c)continue;var txt=(c.textContent||'').trim().replace(/\s+/g,' ');max=Math.max(max,Math.min(360,Math.round(Math.min(txt.length,45)*6+24)));}}var id=colIds(tb)[i];setGridWidth(key,id,max);var cg=ensureColgroup(tb,key);if(cg.children[i])cg.children[i].style.width=max+'px';syncTableWidth(tb,key);requestAnimationFrame(function(){applyPins(tb,key);adjustGroupedHeader(tb,key,effectiveHidden(tb,key));try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}});}
  function autoFitAll(key){var tb=findTable(key);if(!tb)return;headers(tb).forEach(function(_,i){autoFitColumn(tb,key,i);});}
  function addGenericResizers(tb,key){tb.querySelectorAll('.colrz,.geo-col-resizer').forEach(function(x){x.remove();});tb.querySelectorAll('.case-grid-resizer').forEach(function(x){if(x.dataset.caseResizerVersion!=='4325')x.remove();});var hs=headers(tb),cg=ensureColgroup(tb,key),ids=colIds(tb);hs.forEach(function(th,i){var id=ids[i],old=th.querySelector('.case-grid-resizer');if(old&&old.dataset.caseColId===id)return;if(old)old.remove();th.style.position='';/* v4.48: НЕ ставим inline relative — он перебивал position:sticky шапки (корень появления клона) */var h=document.createElement('span');h.className='case-grid-resizer';h.dataset.caseColId=id;h.dataset.caseResizerVersion='4325';h.title='Изменить ширину · двойной клик — автоподбор';h.addEventListener('click',function(ev){ev.stopPropagation();});h.addEventListener('dblclick',function(ev){ev.preventDefault();ev.stopPropagation();var ci=colIds(tb).indexOf(id);if(ci>=0)autoFitColumn(tb,key,ci);});h.addEventListener('pointerdown',function(ev){if(ev.button!==0)return;ev.preventDefault();ev.stopPropagation();var currentIds=colIds(tb),ci=currentIds.indexOf(id);if(ci<0)return;cg=ensureColgroup(tb,key);var col=cg.children[ci];if(!col)return;h.classList.add('drag');tb.dataset.cgResizing='1';var sx=ev.clientX,sw=parseFloat(col.style.width)||headers(tb)[ci].getBoundingClientRect().width,lastW=sw,persistT=0;try{h.setPointerCapture(ev.pointerId);}catch(_){}var persist=function(){clearTimeout(persistT);persistT=setTimeout(function(){setGridWidth(key,id,lastW);},70);};var move=function(x){lastW=Math.max(32,Math.min(600,sw+(x.clientX-sx)));col.style.width=Math.round(lastW)+'px';syncTableWidth(tb,key);adjustGroupedHeader(tb,key,effectiveHidden(tb,key));applyPins(tb,key);persist();try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}};var up=function(x){document.removeEventListener('pointermove',move,true);document.removeEventListener('pointerup',up,true);document.removeEventListener('pointercancel',up,true);document.removeEventListener('mousemove',move,true);document.removeEventListener('mouseup',up,true);window.removeEventListener('blur',up,true);h.classList.remove('drag');delete tb.dataset.cgResizing;try{h.releasePointerCapture(x&&x.pointerId);}catch(_){}lastW=Math.max(32,Math.min(600,lastW));col.style.width=Math.round(lastW)+'px';clearTimeout(persistT);setGridWidth(key,id,lastW);syncTableWidth(tb,key);applyPins(tb,key);try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}};document.addEventListener('pointermove',move,true);document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',up,true);document.addEventListener('mousemove',move,true);document.addEventListener('mouseup',up,true);window.addEventListener('blur',up,true);});th.appendChild(h);});}

  function normalizeHeader(th,i){if(th.querySelector('.th1r,.geo-th-label,.case-grid-th')||th.querySelector('input,select,button'))return;var raw=(th.textContent||'').trim();if(!raw)return;th.textContent='';var w=document.createElement('div');w.className='case-grid-th';var l=document.createElement('span');l.className='case-grid-label';l.textContent=raw;w.appendChild(l);th.appendChild(w);}

  function genericState(key){var p=tablePref(key).one;p.generic=p.generic||{filters:{},sort:null};return p.generic;}
  function setGeneric(key,fn){mutatePref(key,function(p){p.generic=p.generic||{filters:{},sort:null};fn(p.generic);});var tb=findTable(key);if(tb){prepareGeneric(tb,key);applyGeneric(tb,key);}}
  function genericColVal(row,i){var c=cellAt(row,i);return c?(c.textContent||'').trim().replace(/\s+/g,' '):'';}
  function genericNumber(v){var n=Number(String(v==null?'':v).replace(/\s/g,'').replace(/[^0-9,.-]/g,'').replace(',','.'));return Number.isFinite(n)?n:null;}
  function genericConditionPass(v,f){if(!f)return true;var op=f.op||((f.q||'')?'contains':''),a=f.a!=null?String(f.a):String(f.q||''),b=f.b!=null?String(f.b):'';if(!op)return true;var low=String(v||'').toLowerCase(),aa=a.toLowerCase();if(op==='contains')return low.indexOf(aa)>=0;if(op==='notcontains')return low.indexOf(aa)<0;if(op==='starts')return low.indexOf(aa)===0;if(op==='ends')return aa===''||low.slice(-aa.length)===aa;if(op==='eqtxt')return low===aa;if(op==='neqtxt')return low!==aa;if(op==='empty')return !String(v||'').trim();if(op==='notempty')return !!String(v||'').trim();var n=genericNumber(v),na=genericNumber(a),nb=genericNumber(b);if(n==null||na==null)return false;if(op==='gt')return n>na;if(op==='ge')return n>=na;if(op==='lt')return n<na;if(op==='le')return n<=na;if(op==='eq')return n===na;if(op==='neq')return n!==na;if(op==='between')return nb!=null&&n>=Math.min(na,nb)&&n<=Math.max(na,nb);if(op==='notbetween')return nb!=null&&(n<Math.min(na,nb)||n>Math.max(na,nb));return true;}
  function applyGeneric(tb,key){var st=genericState(key),hs=headers(tb),body=tb.tBodies&&tb.tBodies[0];if(!body)return;var ids=colIds(tb);Array.prototype.forEach.call(body.rows,function(r,ri){if(!r.dataset.caseOrig)r.dataset.caseOrig=String(ri);var ok=true;Object.keys(st.filters||{}).forEach(function(id){var f=st.filters[id],i=ids.indexOf(id);if(i<0||!f)return;var v=genericColVal(r,i),vv=v===''?'(Пусто)':v;if(Array.isArray(f.vals)&&f.vals.indexOf(vv)<0)ok=false;if(!genericConditionPass(v,f))ok=false;});r.classList.toggle('case-grid-filtered',!ok);});if(st.sort){var si=ids.indexOf(st.sort.id),dir=st.sort.dir||1;if(si>=0){var rows=Array.prototype.slice.call(body.rows),normal=rows.filter(function(r){return r.cells.length===hs.length&&!r.querySelector('td[colspan]');}),extra=rows.filter(function(r){return normal.indexOf(r)<0;});normal.sort(function(a,b){var av=genericColVal(a,si),bv=genericColVal(b,si),an=genericNumber(av),bn=genericNumber(bv);if(an!=null&&bn!=null)return(an-bn)*dir;return av.localeCompare(bv,'ru',{numeric:true,sensitivity:'base'})*dir;});normal.concat(extra).forEach(function(r){body.appendChild(r);});}}hs.forEach(function(th,i){var id=ids[i],b=th.querySelector('.case-grid-filter-btn');if(!b)return;b.classList.toggle('on',!!(st.filters&&st.filters[id]));b.classList.remove('sort-asc','sort-desc');if(st.sort&&st.sort.id===id)b.classList.add(st.sort.dir>0?'sort-asc':'sort-desc');});}
  function prepareGeneric(tb,key){if(isKnownEngine(tb))return;var hs=headers(tb),ids=colIds(tb);hs.forEach(function(th,i){normalizeHeader(th,i);var wrap=th.querySelector('.case-grid-th');if(!wrap)return;var label=wrap.querySelector('.case-grid-label');if(label){label.style.cursor='default';label.title=label.textContent||'';}if(!wrap.querySelector('.case-grid-filter-btn')){var b=document.createElement('span');b.className='case-grid-filter-btn';b.textContent='▾';b.title='Фильтр, сортировка и столбец';b.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();openGenericMenu(tb,key,i,b);});wrap.appendChild(b);}});applyGeneric(tb,key);}
  function closeMenu(){if(OPEN_MENU){OPEN_MENU.remove();OPEN_MENU=null;}document.removeEventListener('mousedown',menuAway,true);}
  function menuAway(ev){if(OPEN_MENU&&!OPEN_MENU.contains(ev.target))closeMenu();}
  function openGenericMenu(tb,key,i,anchor){closeMenu();var ids=colIds(tb),id=ids[i],st=genericState(key),f=(st.filters||{})[id]||{},vals=[],seen={},numeric=0,nonempty=0;var body=tb.tBodies&&tb.tBodies[0];if(body)Array.prototype.forEach.call(body.rows,function(r){var raw=genericColVal(r,i),v=raw||'(Пусто)';if(!seen[v]){seen[v]=1;vals.push(v);}if(raw){nonempty++;if(genericNumber(raw)!=null)numeric++;}});var isNum=nonempty>0&&numeric/nonempty>=.75;vals.sort(function(a,b){return a.localeCompare(b,'ru',{numeric:true,sensitivity:'base'});});var selected=Array.isArray(f.vals)?f.vals.slice():vals.slice(),op=f.op||((f.q||'')?'contains':''),a=f.a!=null?f.a:(f.q||''),bb=f.b||'';var ops=isNum?[['','— без условия —'],['gt','Больше (>)'],['ge','Больше или равно (≥)'],['lt','Меньше (<)'],['le','Меньше или равно (≤)'],['eq','Равно (=)'],['neq','Не равно (≠)'],['between','Между'],['notbetween','Вне диапазона'],['empty','Пусто'],['notempty','Не пусто']]:[['','— без условия —'],['contains','Содержит'],['notcontains','Не содержит'],['starts','Начинается с'],['ends','Заканчивается на'],['eqtxt','Равно'],['neqtxt','Не равно'],['empty','Пусто'],['notempty','Не пусто']];var m=document.createElement('div');m.className='case-grid-menu';m.innerHTML='<div class="cg-sort"><button data-sort="1">▲ '+(isNum?'По возрастанию':'А → Я')+'</button><button data-sort="-1">▼ '+(isNum?'По убыванию':'Я → А')+'</button></div><div class="cg-title">Условие</div><select data-op style="width:100%;padding:7px;border:1px solid var(--border);border-radius:7px;background:var(--panel);color:var(--ink)">'+ops.map(function(x){return '<option value="'+x[0]+'" '+(op===x[0]?'selected':'')+'>'+x[1]+'</option>';}).join('')+'</select><div data-cond style="margin-top:5px"><input type="search" data-a placeholder="'+(isNum?'Значение':'Текст')+'" value="'+e(a)+'"><input type="search" data-b placeholder="Верхняя граница" value="'+e(bb)+'" style="margin-top:5px;display:'+(op==='between'||op==='notbetween'?'block':'none')+'"></div><div class="cg-title">Фильтр значений</div><input type="search" data-search placeholder="Поиск значения"><div style="font-size:10.5px;margin:5px 0"><a href="#" data-all="1">Выбрать все</a> · <a href="#" data-all="0">Снять все</a></div><div class="cg-values">'+vals.slice(0,500).map(function(v){return '<label><input type="checkbox" data-value="'+e(v)+'" '+(selected.indexOf(v)>=0?'checked':'')+'><span>'+e(v)+'</span></label>';}).join('')+'</div><button data-hide style="width:100%;margin-top:7px;text-align:left">Скрыть столбец</button><div class="cg-footer"><button data-reset>Сбросить</button><span class="sp"></span><button data-cancel>Отмена</button><button class="primary" data-apply>Применить</button></div>';document.body.appendChild(m);OPEN_MENU=m;var r=anchor.getBoundingClientRect(),mw=Math.min(310,window.innerWidth-16);m.style.width=mw+'px';m.style.left=Math.max(8,Math.min(r.left,window.innerWidth-mw-8))+'px';var top=r.bottom+4;if(top+m.offsetHeight>window.innerHeight-8)top=Math.max(8,window.innerHeight-m.offsetHeight-8);m.style.top=top+'px';m.querySelectorAll('[data-sort]').forEach(function(b){b.onclick=function(){var d=+b.dataset.sort;closeMenu();setGeneric(key,function(x){x.sort={id:id,dir:d};});};});var opEl=m.querySelector('[data-op]'),bEl=m.querySelector('[data-b]'),cond=m.querySelector('[data-cond]');opEl.onchange=function(){var o=opEl.value;bEl.style.display=(o==='between'||o==='notbetween')?'block':'none';cond.style.display=(o==='empty'||o==='notempty'||!o)?(o?'none':'block'):'block';};opEl.onchange();var search=m.querySelector('input[data-search]');search.oninput=function(){var q=search.value.toLowerCase();m.querySelectorAll('.cg-values label').forEach(function(l){l.style.display=l.textContent.toLowerCase().indexOf(q)>=0?'flex':'none';});};m.querySelectorAll('[data-all]').forEach(function(a0){a0.onclick=function(ev){ev.preventDefault();var on=a0.dataset.all==='1';m.querySelectorAll('.cg-values label').forEach(function(l){if(l.style.display!=='none')l.querySelector('input').checked=on;});};});m.querySelector('[data-hide]').onclick=function(){closeMenu();hideColumn(key,id);};m.querySelector('[data-reset]').onclick=function(){closeMenu();setGeneric(key,function(x){delete x.filters[id];if(x.sort&&x.sort.id===id)x.sort=null;});};m.querySelector('[data-cancel]').onclick=closeMenu;m.querySelector('[data-apply]').onclick=function(){var selectedVals=[],o=opEl.value,aa=(m.querySelector('[data-a]').value||'').trim(),bbb=(bEl.value||'').trim();m.querySelectorAll('.cg-values input:checked').forEach(function(c){selectedVals.push(c.dataset.value);});closeMenu();setGeneric(key,function(x){x.filters=x.filters||{};if(selectedVals.length===vals.length&&!o)delete x.filters[id];else{x.filters[id]={};if(selectedVals.length!==vals.length)x.filters[id].vals=selectedVals;if(o){x.filters[id].op=o;if(o!=='empty'&&o!=='notempty')x.filters[id].a=aa;if(o==='between'||o==='notbetween')x.filters[id].b=bbb;}}});};setTimeout(function(){document.addEventListener('mousedown',menuAway,true);},0);}

  function findTable(key){return document.querySelector('table[data-case-grid-key="'+cssEsc(key)+'"]');}
  function closePanel(){if(OPEN_PANEL){OPEN_PANEL.remove();OPEN_PANEL=null;}document.removeEventListener('mousedown',panelAway,true);}
  function panelAway(ev){if(OPEN_PANEL&&!OPEN_PANEL.contains(ev.target)&&!ev.target.closest('.case-grid-toolbar'))closePanel();}
  function mandatoryColumn(key,id){return id==='_select'||id==='code';}
  function refreshGridToolbar(tb,key){var wrap=tb&&(tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap')||tb.parentElement),shell=wrap&&wrap.parentElement;if(!shell)return;var old=shell.querySelector(':scope > .case-grid-toolbar[data-for="'+cssEsc(key)+'"]');if(old)old.remove();toolbar(tb,key,0);}
  function applyColumnPrefsLive(key){var tb=findTable(key);if(!tb)return false;ensureColgroup(tb,key);applyVisibility(tb,key);applyPins(tb,key);refreshGridToolbar(tb,key);try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}return true;}
  function hideColumn(key,id){if(mandatoryColumn(key,id)){alert('Этот системный столбец нельзя скрыть.');return;}mutatePref(key,function(p){p.hidden=p.hidden||{};p.hidden[id]=1;});closeMenu();closePanel();if(!applyColumnPrefsLive(key))refresh();}
  function showColumn(key,id){mutatePref(key,function(p){p.hidden=p.hidden||{};delete p.hidden[id];});closeMenu();closePanel();if(!applyColumnPrefsLive(key))refresh();}
  function openColumnMenu(key,id,anchor){var tb=findTable(key);if(!tb)return;var ids=colIds(tb),i=ids.indexOf(id);if(i<0)return;if(!isKnownEngine(tb)){openGenericMenu(tb,key,i,anchor);return;}closeMenu();var m=document.createElement('div');m.className='case-grid-menu';m.innerHTML='<button data-hide style="width:100%;text-align:left">Скрыть столбец</button><button data-cols style="width:100%;text-align:left;margin-top:6px">Открыть список столбцов</button>';document.body.appendChild(m);OPEN_MENU=m;var r=anchor.getBoundingClientRect(),mw=250;m.style.width=mw+'px';m.style.left=Math.max(8,Math.min(r.left,window.innerWidth-mw-8))+'px';m.style.top=Math.min(r.bottom+4,window.innerHeight-m.offsetHeight-8)+'px';m.querySelector('[data-hide]').onclick=function(){closeMenu();hideColumn(key,id);};m.querySelector('[data-cols]').onclick=function(){closeMenu();openColumns(key,anchor);};setTimeout(function(){document.addEventListener('mousedown',menuAway,true);},0);}
  function openColumns(key,anchor){closePanel();var tb=findTable(key);if(!tb)return;var ids=colIds(tb),hs=headers(tb),p=tablePref(key).one,hidden=p.hidden||{},canOrder=!!(tb.tHead&&(tb.tHead.rows.length===1||tb.classList.contains('asaas35-table'))),cap=maxPinCount(tb,key);var panel=document.createElement('div');panel.className='case-grid-panel';var rows=ids.map(function(id,i){var label=(hs[i].querySelector('.th-name,.case-grid-label,.geo-th-label')||hs[i]).textContent.trim()||('Столбец '+(i+1)),locked=mandatoryColumn(key,id);return '<div class="cg-row" data-col="'+e(id)+'"><input type="checkbox" data-id="'+e(id)+'" '+(!hidden[id]?'checked':'')+' '+(locked?'disabled':'')+'><span title="'+e(label)+'">'+e(label)+(locked?' · обязательный':'')+'</span>'+(canOrder?'<button type="button" data-up title="Выше">↑</button><button type="button" data-down title="Ниже">↓</button>':'')+'</div>';}).join('');var hiddenN=Object.keys(hidden).filter(function(id){return hidden[id];}).length;panel.innerHTML='<h3>Столбцы таблицы</h3><div class="cg-sub">Скрыто: '+hiddenN+'. Настройки личные для пользователя.</div><input type="search" data-search placeholder="Поиск столбца" style="width:100%;box-sizing:border-box;margin-bottom:7px"><div style="display:flex;gap:6px;margin-bottom:7px"><button data-show-all>Показать все</button><button data-hide-optional>Скрыть необязательные</button></div><div data-col-list>'+rows+'</div><div class="cg-row"><span>Закрепить первых видимых столбцов</span><select data-pin>'+Array.from({length:cap+1},function(_,n){return '<option value="'+n+'" '+(((('pin' in p)?+p.pin:defaultPin(key))===n)?'selected':'')+'>'+n+'</option>';}).join('')+'</select></div><div class="cg-actions"><button data-close>Отмена</button><button class="primary" data-save>Применить</button></div>';document.body.appendChild(panel);OPEN_PANEL=panel;var r=anchor.getBoundingClientRect(),w=Math.min(410,window.innerWidth-20);panel.style.width=w+'px';panel.style.left=Math.max(10,Math.min(r.right-w,window.innerWidth-w-10))+'px';var top=r.bottom+5;if(top+panel.offsetHeight>window.innerHeight-10)top=Math.max(10,window.innerHeight-panel.offsetHeight-10);panel.style.top=top+'px';panel.querySelector('[data-close]').onclick=closePanel;panel.querySelector('[data-search]').oninput=function(){var q=this.value.toLowerCase();panel.querySelectorAll('[data-col]').forEach(function(row){row.style.display=row.textContent.toLowerCase().indexOf(q)>=0?'flex':'none';});};panel.querySelector('[data-show-all]').onclick=function(){panel.querySelectorAll('[data-col] input').forEach(function(c){c.checked=true;});};panel.querySelector('[data-hide-optional]').onclick=function(){panel.querySelectorAll('[data-col]').forEach(function(row){var c=row.querySelector('input');if(!c.disabled)c.checked=false;});};if(canOrder)panel.querySelectorAll('[data-up],[data-down]').forEach(function(b){b.onclick=function(){var row=b.closest('[data-col]'),other=b.hasAttribute('data-up')?row.previousElementSibling:row.nextElementSibling;if(!other||!other.hasAttribute('data-col'))return;if(b.hasAttribute('data-up'))row.parentNode.insertBefore(row,other);else row.parentNode.insertBefore(other,row);};});panel.querySelector('[data-save]').onclick=function(){var h={},checked=0,ord=[];panel.querySelectorAll('[data-col]').forEach(function(row){var c=row.querySelector('input[data-id]');ord.push(row.dataset.col);if(c.checked)checked++;else h[c.dataset.id]=1;});if(!checked){alert('Оставьте видимым хотя бы один столбец.');return;}var pin=+panel.querySelector('[data-pin]').value;mutatePref(key,function(x){x.hidden=h;x.pin=pin;x._pinModel='4322';if(canOrder)x.order=ord;});closePanel();refresh();};setTimeout(function(){document.addEventListener('mousedown',panelAway,true);},0);}
  function openViewPanel(key,anchor,canColumns){closePanel();var tb=findTable(key);if(!tb)return;var p=tablePref(key).one,d=p.density||'comfortable',hiddenN=Object.keys(p.hidden||{}).filter(function(id){return p.hidden[id];}).length;var panel=document.createElement('div');panel.className='case-grid-panel';panel.innerHTML='<h3>Вид таблицы</h3><div class="cg-sub">Личная настройка — не влияет на других сотрудников.</div><button type="button" data-columns style="width:100%;text-align:left;margin-bottom:7px">☷ Столбцы'+(hiddenN?' · скрыто '+hiddenN:'')+'</button><div class="cg-row"><span>Плотность строк</span><select data-density><option value="comfortable" '+(d==='comfortable'?'selected':'')+'>Комфортная</option><option value="compact" '+(d==='compact'?'selected':'')+'>Компактная</option><option value="ultra" '+(d==='ultra'?'selected':'')+'>Максимальная</option></select></div><button type="button" data-fit style="width:100%;text-align:left;margin-top:7px">↔ Автоподбор ширины</button><button type="button" data-unpin style="width:100%;text-align:left;margin-top:7px">Открепить все столбцы</button><button type="button" data-reset style="width:100%;text-align:left;margin-top:7px">↺ Восстановить стандартный вид</button><div class="cg-actions"><button data-close>Закрыть</button></div>';document.body.appendChild(panel);OPEN_PANEL=panel;var r=anchor.getBoundingClientRect(),w=Math.min(370,window.innerWidth-20);panel.style.width=w+'px';panel.style.left=Math.max(10,Math.min(r.right-w,window.innerWidth-w-10))+'px';var top=r.bottom+5;if(top+panel.offsetHeight>window.innerHeight-10)top=Math.max(10,window.innerHeight-panel.offsetHeight-10);panel.style.top=top+'px';panel.querySelector('[data-close]').onclick=closePanel;panel.querySelector('[data-columns]').onclick=function(){closePanel();openColumns(key,anchor);};panel.querySelector('[data-density]').onchange=function(){var v=this.value;closePanel();setDensity(key,v);};panel.querySelector('[data-fit]').onclick=function(){autoFitAll(key);closePanel();};panel.querySelector('[data-unpin]').onclick=function(){mutatePref(key,function(x){x.pin=0;x._pinModel='4322';});closePanel();refresh();};panel.querySelector('[data-reset]').onclick=function(){if(confirm('Сбросить ширины, порядок, скрытые и закреплённые столбцы, плотность и локальные фильтры?')){closePanel();resetTable(key);}};setTimeout(function(){document.addEventListener('mousedown',panelAway,true);},0);}
  function resetTable(key){var p=loadPrefs();delete p[key];savePrefs(p);try{var old=typeof _tblColW==='function'?_tblColW():null;if(old&&old[key]){delete old[key];if(typeof _tblColWSave==='function')_tblColWSave(old);}}catch(_){}refresh();}
  function refresh(){closeMenu();closePanel();try{if(typeof go==='function'&&typeof S!=='undefined'&&S&&S.view){go(S.view);return;}}catch(_){}enhanceAll();}
  function toolbar(tb,key,idx){if(!isMainGrid(tb))return;var wrap=tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap')||tb.parentElement;if(!wrap)return;var shell=wrap.parentElement;if(!shell)return;var old=shell.querySelector(':scope > .case-grid-toolbar[data-for="'+cssEsc(key)+'"]');if(old)return;var bar=document.createElement('div');bar.className='case-grid-toolbar';bar.dataset.for=key;var p=tablePref(key).one,hiddenN=Object.keys(p.hidden||{}).filter(function(id){return p.hidden[id];}).length;bar.innerHTML='<span class="cg-caption">Показано '+((tb.tBodies&&tb.tBodies[0])?tb.tBodies[0].rows.length:0)+' строк · '+headers(tb).length+' столбцов</span><span class="cg-spacer"></span><button data-columns title="Скрыть или вернуть столбцы">☷ Столбцы'+(hiddenN?' · '+hiddenN:'')+'</button><button data-view title="Ширина, плотность и закрепление">⚙ Вид</button>';shell.insertBefore(bar,wrap);var bc=bar.querySelector('[data-columns]'),bv=bar.querySelector('[data-view]');bc.onclick=function(){openColumns(key,bc);};bv.onclick=function(){openViewPanel(key,bv,true);};}
  function enhanceTable(tb,idx){if(!tb||!tb.tHead||!tb.tBodies||!tb.tBodies.length||tb.dataset.cgResizing==='1')return;var key=tableKey(tb,idx);tb.dataset.caseGridKey=key;tb.classList.add('case-grid');tb.setAttribute('data-colr','case-grid');tb.querySelectorAll('.colrz,.geo-col-resizer').forEach(function(x){x.remove();});colIds(tb);applyOrder(tb,key);colIds(tb);headers(tb).forEach(normalizeHeader);applyDensity(tb,key);applyStoredWidths(tb,key);applyVisibility(tb,key);prepareGeneric(tb,key);addGenericResizers(tb,key);toolbar(tb,key,idx);requestAnimationFrame(function(){applyPins(tb,key);adjustGroupedHeader(tb,key,effectiveHidden(tb,key));try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}});}
  function enhanceAll(){injectCss();maybePullServerPrefs();document.querySelectorAll('.case-grid-resizer').forEach(function(r){if(!r.closest('th'))r.remove();}); /* v4.43.2: осиротевшие резайзеры (полоса во всю высоту) */var view=currentView();document.querySelectorAll('.case-grid-menu[data-case-grid-owner]').forEach(function(m){if(m.dataset.caseGridOwner!==view)m.remove();});var root=document.getElementById('main')||document;var tables=root.querySelectorAll('table');tables.forEach(function(tb,i){try{enhanceTable(tb,i);}catch(err){try{console.warn('CASE Grid:',err);}catch(_){}}});try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){}
  /* v4.46.4: синк прилипшей шапки ПОСЛЕ rAF-этапа (пины/группы применяются в rAF внутри enhanceTable) —
     иначе клон строился без закреплённых столбцов */
  requestAnimationFrame(function(){try{if(typeof window.CASE_SYNC_STICKY==='function')window.CASE_SYNC_STICKY();}catch(_){}});}
  function schedule(){if(document.querySelector('table.case-grid[data-cg-resizing="1"]'))return;var now=Date.now();if(!schedule._first)schedule._first=now;clearTimeout(TIMER);
    /* v4.43.2: защита от «голодания» — при непрерывном потоке мутаций (штормящий модуль)
       дебаунс никогда не срабатывал и новые таблицы оставались без улучшения */
    if(now-schedule._first>600){schedule._first=0;TIMER=setTimeout(enhanceAll,0);return;}
    TIMER=setTimeout(function(){schedule._first=0;enhanceAll();},90);}

  /* ===== v4.48.0: НАТИВНАЯ прилипшая шапка — БЕЗ клона.
     Прилипает настоящий thead внутри прокручиваемой обёртки (position:sticky), поэтому
     линии, закрепления и резайзеры совпадают с телом ПО ПОСТРОЕНИЮ — это один элемент.
     Обёртке главного грида задаётся высота по экрану, чтобы вертикальная прокрутка
     всегда была внутренней. Клон-слоёв больше нет — нечему рассинхронизироваться. */
  var stickyBound=false,stickyCapRaf=0;
  function pageScroller(){return document.scrollingElement||document.documentElement||document.body;}
  function topbarHeight(){var bar=document.querySelector('.topbar');return bar?Math.max(0,Math.ceil(bar.getBoundingClientRect().height)):0;}
  function hasVerticalRange(el){if(!el)return false;var cs=getComputedStyle(el),oy=cs.overflowY;return (oy==='auto'||oy==='scroll')&&(el.scrollHeight-el.clientHeight>2);}
  function parentVerticalScroller(el){var n=el&&el.parentElement;while(n&&n!==document.body&&n!==document.documentElement){if(hasVerticalRange(n))return n;n=n.parentElement;}return pageScroller();}
  function handoffWheel(e){
    if(e.defaultPrevented||e.ctrlKey||e.metaKey||Math.abs(e.deltaY)<=Math.abs(e.deltaX))return;var sc=e.currentTarget;if(!hasVerticalRange(sc))return;
    var max=Math.max(0,sc.scrollHeight-sc.clientHeight),atTop=sc.scrollTop<=1,atBottom=sc.scrollTop>=max-1;if(!((e.deltaY<0&&atTop)||(e.deltaY>0&&atBottom)))return;
    var parent=parentVerticalScroller(sc),before=parent===pageScroller()?(parent.scrollTop||window.scrollY||0):parent.scrollTop;parent.scrollTop=before+e.deltaY;var after=parent===pageScroller()?(parent.scrollTop||window.scrollY||0):parent.scrollTop;if(after!==before){e.preventDefault();e.stopPropagation();}
  }
  function installScrollHandoff(wrap){if(!wrap||wrap.dataset.caseScrollHandoff==='4327')return;wrap.dataset.caseScrollHandoff='4327';wrap.style.overscrollBehaviorY='auto';wrap.addEventListener('wheel',handoffWheel,{passive:false});}
  function capMainGridWrap(tb,wrap){
    if(!wrap||!isMainGrid(tb))return;
    var top=Math.max(topbarHeight(),Math.round(wrap.getBoundingClientRect().top));
    var h=Math.max(260,window.innerHeight-top-14);
    var want=h+'px';
    if(wrap.style.maxHeight!==want)wrap.style.maxHeight=want;
  }
  function buildGrpBand(tb){
    /* v4.48.3: полоса «Бюджет/Факт» — div-дублёр группового ряда. Обычный блок в потоке:
       горизонтально едет с таблицей сам, вертикально липнет (sticky top:0); ряд колонок
       липнет под ним (top = высота полосы). Chromium не умеет прилеплять два ряда ЯЧЕЕК
       на разных top — а div+ячейки на едином top работают. Ширины — из реальных rect'ов. */
    var wrap=tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap');if(!wrap)return;
    var old=wrap.querySelector(':scope > .case-grp-band');if(old)old.remove();
    if(!tb.classList.contains('reg-grp')||!tb.tHead||tb.tHead.rows.length<2)return;
    var gr=tb.tHead.rows[0],cells=Array.prototype.slice.call(gr.cells);
    var bud=cells.find(function(c){return c.classList.contains('grp-bud');}),fac=cells.find(function(c){return c.classList.contains('grp-fac');});
    if(!bud||!fac)return;
    var tr=tb.getBoundingClientRect(),br=bud.getBoundingClientRect(),fr=fac.getBoundingClientRect();
    var grpH=Math.max(1,Math.ceil(gr.getBoundingClientRect().height));
    var band=document.createElement('div');band.className='case-grp-band';
    band.style.width=Math.ceil(tr.width)+'px';band.style.height=grpH+'px';band.style.marginBottom=(-grpH)+'px';
    var preW=Math.max(0,Math.round(br.x-tr.x));
    band.innerHTML='<div class="cgb-pre" style="width:'+preW+'px"></div>'+
      '<div class="cgb-bud" style="width:'+Math.round(br.width)+'px">'+bud.innerHTML+'</div>'+
      '<div class="cgb-fac" style="width:'+Math.round(fr.width)+'px">'+fac.innerHTML+'</div>'+
      '<div class="cgb-post"></div>';
    band.addEventListener('click',function(e){
      var t=e.target.closest('.cgb-bud,.cgb-fac');if(!t)return;e.preventDefault();e.stopPropagation();
      var real=t.classList.contains('cgb-bud')?bud:fac;
      try{real.dispatchEvent(new MouseEvent('click',{bubbles:true,clientX:e.clientX,clientY:e.clientY}));}catch(_){ }
    });
    wrap.insertBefore(band,tb);
  }
  function buildPinCorner(tb,key){
    /* v4.48.2: УГЛОВОЙ БЛОК закреплённых заголовков. Chromium не отрисовывает ни двухосевой
       position:sticky, ни transform на ячейках таблицы (rect верный, paint нет — проверено
       elementFromPoint). Поэтому закреплённые ЗАГОЛОВКИ показывает маленький div-двойник,
       прилипший в углу обёртки нативным двухосевым sticky (на div он работает). Никакого
       слежения за прокруткой: геометрию держит браузер. Перестраивается в applyPins. */
    var wrap=tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap');if(!wrap)return;
    var old=wrap.querySelector(':scope > .case-pin-corner');if(old)old.remove();
    var leaf=tb.tHead&&tb.tHead.rows[tb.tHead.rows.length-1];if(!leaf)return;
    var pins=Array.prototype.filter.call(leaf.cells,function(c){return c.classList.contains('case-grid-pin');});
    if(!pins.length)return;
    var grpH=tb.tHead.rows.length>1?Math.max(0,Math.ceil(tb.tHead.rows[0].getBoundingClientRect().height)):0;
    var leafH=Math.max(1,Math.ceil(leaf.getBoundingClientRect().height));
    var box=document.createElement('div');box.className='case-pin-corner';
    var totalW=0;
    var inner='<div class="cpc-grp" style="height:'+grpH+'px"></div><div class="cpc-row" style="height:'+leafH+'px">';
    pins.forEach(function(th){
      var w=Math.round(th.getBoundingClientRect().width);totalW+=w;
      inner+='<div class="cpc-cell" data-src-col="'+(th.dataset.caseColId||'')+'" style="width:'+w+'px">'+th.innerHTML+'</div>';
    });
    inner+='</div>';
    box.innerHTML=inner;
    box.style.width=totalW+'px';box.style.height=(grpH+leafH)+'px';box.style.marginBottom=-(grpH+leafH)+'px';
    /* прокси: клики (сортировка/фильтр/меню) и резайзеры уходят настоящим ячейкам */
    box.addEventListener('pointerdown',function(e){
      var rz=e.target&&e.target.closest&&e.target.closest('.case-grid-resizer');if(!rz)return;
      var id=rz.dataset&&rz.dataset.caseColId;if(!id)return;
      var real=tb.querySelector('thead .case-grid-resizer[data-case-col-id="'+cssEsc(id)+'"]');
      if(!real)return;e.preventDefault();e.stopPropagation();
      try{real.dispatchEvent(new PointerEvent('pointerdown',{button:0,clientX:e.clientX,clientY:e.clientY,bubbles:true,pointerId:e.pointerId||1}));}catch(_){ }
    });
    box.addEventListener('click',function(e){
      if(e.target.closest('.case-grid-resizer'))return;
      var cell=e.target.closest('.cpc-cell');if(!cell)return;
      var id=cell.dataset.srcCol;var th=id?tb.querySelector('thead th[data-case-col-id="'+cssEsc(id)+'"]'):null;
      if(!th)return;
      var btn=e.target.closest('button, .tblfnl, .case-grid-filter-btn, a');
      var realBtn=null;
      if(btn){var sel=btn.className?('.'+String(btn.className).trim().split(/\s+/).join('.')):btn.tagName;try{realBtn=th.querySelector(sel);}catch(_){realBtn=null;}}
      e.preventDefault();e.stopPropagation();
      try{(realBtn||th).dispatchEvent(new MouseEvent('click',{bubbles:true,clientX:e.clientX,clientY:e.clientY}));}catch(_){ }
    });
    wrap.insertBefore(box,wrap.firstChild);
  }
  function syncOneStickyTable(tb){
    if(!tb||!tb.tHead)return;var wrap=tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap');
    var rows=tb.tHead.rows,gh=0;
    if(rows.length>1){gh=Math.max(1,Math.ceil(rows[0].getBoundingClientRect().height));tb.style.setProperty('--cg-group-h',gh+'px');}
    /* v4.48.1: липнет только ряд колонок (leaf) на top:0 — Chromium игнорирует разные top
       у sticky-ячеек многорядного thead; групповой ряд прокручивается. Инлайн-top чистим. */
    Array.prototype.forEach.call(tb.tHead.querySelectorAll('th'),function(th){if(th.style.top)th.style.top='';});
    capMainGridWrap(tb,wrap);installScrollHandoff(wrap);try{if(!wrap.querySelector(':scope > .case-grp-band'))buildGrpBand(tb);}catch(_){}
  }
  function syncStickyTables(){
    document.documentElement.style.setProperty('--topbar-h',topbarHeight()+'px');
    document.querySelectorAll('.case-sticky-head-layer').forEach(function(l){l.remove();});
    document.querySelectorAll('table.case-grid:not(.case-sticky-head-table)').forEach(syncOneStickyTable);
    if(!stickyBound){stickyBound=true;
      var recap=function(){if(stickyCapRaf)return;stickyCapRaf=requestAnimationFrame(function(){stickyCapRaf=0;document.querySelectorAll('table.case-grid').forEach(function(tb){capMainGridWrap(tb,tb.closest('.tbl-scroll,.geo-table-wrap,.geo-obj-tblwrap'));});});};
      window.addEventListener('resize',recap,{passive:true});
      window.addEventListener('scroll',recap,{passive:true});
    }
  }
  window.CASE_SYNC_STICKY=syncStickyTables;
  window.case432EnhanceNow=function(){try{enhanceAll();}catch(e){}}; /* v4.46.2: синхронное улучшение сразу после точечной перерисовки (live-sync) — без кадра «сырой» таблицы */
  function boot(){injectCss();enhanceAll();var root=document.getElementById('main')||document.body;if(root&&!OBS){OBS=new MutationObserver(schedule);OBS.observe(root,{childList:true,subtree:true});}try{if(typeof window.go==='function'&&!window.go._caseGridWrapped){var originalGo=window.go;var wrapped=function(){var r=originalGo.apply(this,arguments);schedule();setTimeout(enhanceAll,120);return r;};wrapped._caseGridWrapped=true;wrapped._caseGridOriginal=originalGo;window.go=wrapped;}}catch(_){}window.addEventListener('resize',function(){clearTimeout(TIMER);TIMER=setTimeout(function(){document.querySelectorAll('table.case-grid').forEach(function(tb){applyPins(tb,tb.dataset.caseGridKey);});},120);},{passive:true});document.addEventListener('mouseup',function(){var list=document.querySelectorAll('table.case-grid[data-cg-capture="1"]');if(!list.length)return;list.forEach(function(tb){captureWidths(tb,tb.dataset.caseGridKey);});clearTimeout(TIMER);TIMER=setTimeout(enhanceAll,80);},true);}

  function setGroupState(key,anchor){
    var tb=findTable(key);if(!tb)return false;
    ensureColgroup(tb,key);applyVisibility(tb,key);applyPins(tb,key);adjustGroupedHeader(tb,key,effectiveHidden(tb,key));
    requestAnimationFrame(function(){restoreScrollAnchor(tb,key,anchor);try{if(typeof syncTblScroll==='function')syncTblScroll();}catch(_){};try{if(typeof regUpdateGroupUi==='function')regUpdateGroupUi();}catch(_){};});
    return true;
  }
  function resetWidths(key){mutatePref(key,function(p){p.widths={};p.pin=0;p._pinModel='4322';});refresh();}
  window.CASE_GRID={version:GRID_VERSION,enhance:enhanceAll,reset:resetTable,resetWidths:resetWidths,autoFit:autoFitAll,hideColumn:hideColumn,showColumn:showColumn,openColumns:openColumns,openColumnMenu:openColumnMenu,captureScrollAnchor:captureScrollAnchor,setGroupState:setGroupState};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

window.CASE_MODULE_VERSIONS=window.CASE_MODULE_VERSIONS||{};window.CASE_MODULE_VERSIONS['v432-data-grid']='4.49.1';
